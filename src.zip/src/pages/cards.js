import React, { Component } from 'react';
import { Keyboard, ActivityIndicator, Text } from 'react-native';
import api from '../services/api';
import { Container, Form, Input, SubmitButton, List, Card, Title, Image, DetailsButton, DetailsButtonText } from './styles';

export default class Cards extends Component {
  state = {
    characters: [],
    loading: false,
    newCharacter: ''
  };

  handleAddCharacter = async () => {
    const { characters, newCharacter } = this.state;

    try {
      this.setState({ loading: true });

      const response = await api.get(`/api/character/?name=${newCharacter}`);
      console.log(response);
      const character = response.data;

      const data = {
        id: character.id,
        name: character.name,
        status: character.status,
        species: character.species,
        gender: character.gender,
        origin: character.origin.name,
        location: character.location.name
      };

      this.setState({
        characters: [...characters, data],
        newCharacter: '',
        loading: false,
      });

      Keyboard.dismiss();
    } catch (error) {
      console.log(error);
    }
  };

  render() {
    const { characters, newCharacter, loading } = this.state;

    return (
      <Container>
        <Form>
          <Input
            autoCorrect={false}
            autoCapitalize='none'
            placeholder='Adicionar personagem'
            value={newCharacter}
            onChangeText={text => this.setState({ newCharacter: text })}
            returnKeyType='send'
            onSubmitEditing={this.handleAddCharacter}
          />
          <SubmitButton loading={loading} onPress={this.handleAddCharacter}>
            {loading ? <ActivityIndicator color='#fff' /> : <Text style={{ color: '#fff' }}>Adicionar</Text>}
          </SubmitButton>
        </Form>

        <List
          showVerticalScrollIndicator={false}
          data={characters}
          keyExtractor={character => character.id.toString()}
          renderItem={({ item }) => (
            <Card>
              <Name>{item.name}</Name>
            </Card>
          )}
        />
      </Container>
    );
  }
}
