import React, { Component } from 'react';
import api from '../services/api';
import { Container, Header, Name } from './styles';

export default class Card extends Component {
  state = {
    card: {},
    loading: true
  };

  async componentDidMount() {
    const { route } = this.props;
    const { card } = route.params;

    // Fazer a chamada à API para buscar os detalhes do card
    const response = await api.get(`/cards/${card.id}`);
    const cardData = response.data;

    this.setState({ card: cardData, loading: false });
  }

  render() {
    const { card, loading } = this.state;

    if (loading) {
      return <ActivityIndicator />;
    }

    return (
      <Container>
        <Header>
          <Name>{card.name}</Name>
        </Header>
      </Container>
    );
  }
}
